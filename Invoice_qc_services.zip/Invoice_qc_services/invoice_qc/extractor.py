import os
import json
import re
import pdfplumber


def extract_text_from_pdf(pdf_path):
    with pdfplumber.open(pdf_path) as pdf:
        text = ""
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"
        return text


def extract_order_number(text):
    # Example: "Bestellung AUFNR123456"
    match = re.search(r'(AUFNR\s*\d+)', text, re.IGNORECASE)
    if match:
        return match.group(1).replace("AUFNR", "").strip()
    return None


def extract_order_date(text):
    # Example date formats: 02.05.2022 or 2.5.2022
    match = re.search(r'(\d{1,2}\.\d{1,2}\.\d{4})', text)
    if match:
        return match.group(1)
    return None


def extract_currency(text):
    if "EUR" in text:
        return "EUR"
    return None


def extract_totals(text):
    # Matches amounts like 257,04 or 257.04
    def parse_amount(x):
        if not x:
            return None
        x = x.replace(".", "").replace(",", ".")
        return float(x)

    net_match = re.search(r'Gesamtwert\s*EUR\s*([\d\.,]+)', text)
    tax_match = re.search(r'MwSt.*?EUR\s*([\d\.,]+)', text, re.IGNORECASE)
    gross_match = re.search(r'Gesamtwert inkl\. MwSt\. EUR\s*([\d\.,]+)', text, re.IGNORECASE)

    net = parse_amount(net_match.group(1)) if net_match else None
    tax = parse_amount(tax_match.group(1)) if tax_match else None
    gross = parse_amount(gross_match.group(1)) if gross_match else None

    return net, tax, gross


def extract_parties(text):
    """
    Simplest heuristic:
    - The first major address block is buyer
    - The second major address block is seller
    (This is OK for prototype quality)
    """

    # Split into paragraphs
    blocks = [b.strip() for b in text.split("\n\n") if len(b.strip()) > 10]

    buyer = blocks[0] if len(blocks) > 0 else None
    seller = blocks[1] if len(blocks) > 1 else None

    return buyer, seller


def extract_invoices_from_folder(pdf_dir):
    invoices = []

    for filename in os.listdir(pdf_dir):
        if not filename.lower().endswith(".pdf"):
            continue

        pdf_path = os.path.join(pdf_dir, filename)
        text = extract_text_from_pdf(pdf_path)

        order_number = extract_order_number(text)
        order_date = extract_order_date(text)
        currency = extract_currency(text)
        net, tax, gross = extract_totals(text)
        buyer_name, seller_name = extract_parties(text)

        invoice = {
            "order_number": order_number,
            "order_date": order_date,
            "seller_name": seller_name,
            "buyer_name": buyer_name,
            "currency": currency,
            "net_total": net,
            "tax_amount": tax,
            "gross_total": gross,
            "line_items": []
        }

        invoices.append(invoice)

    return invoices


def save_to_json(data, output_file):
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    # Manual test
    folder = "pdfs"
    result = extract_invoices_from_folder(folder)
    save_to_json(result, "extracted_invoices.json")
    print("Extraction complete")
