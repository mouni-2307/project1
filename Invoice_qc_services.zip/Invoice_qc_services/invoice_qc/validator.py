import json
from collections import defaultdict


def validate_invoices(invoices):
    results = []
    seen_ids = set()
    error_counts = defaultdict(int)

    for inv in invoices:
        errors = []

        # --- Completeness Rules ---
        required_fields = ["order_number", "order_date", "seller_name", "buyer_name"]
        for field in required_fields:
            if not inv.get(field):
                errors.append(f"missing_field:{field}")

        # --- Format Rules ---
        # currency constraint
        allowed_currency = {"EUR", "USD", "INR"}
        currency = inv.get("currency")
        if currency and currency not in allowed_currency:
            errors.append("format:invalid_currency")

        # numeric type checks
        for nfield in ["net_total", "tax_amount", "gross_total"]:
            val = inv.get(nfield)
            if val is not None and not isinstance(val, (int, float)):
                errors.append(f"format:not_numeric:{nfield}")

        # --- Business Rules ---
        net = inv.get("net_total")
        tax = inv.get("tax_amount")
        gross = inv.get("gross_total")

        if net is not None and tax is not None and gross is not None:
            if abs((net + tax) - gross) > 0.01:
                errors.append("business:totals_mismatch")

        # --- Duplicate Rule ---
        invoice_key = (inv.get("order_number"), inv.get("order_date"), inv.get("seller_name"))
        if invoice_key in seen_ids:
            errors.append("duplicate:invoice")
        else:
            seen_ids.add(invoice_key)

        # --- Determine validity ---
        is_valid = len(errors) == 0

        results.append({
            "invoice_id": inv.get("order_number"),
            "is_valid": is_valid,
            "errors": errors
        })

        for err in errors:
            error_counts[err] += 1

    summary = {
        "total_invoices": len(invoices),
        "valid_invoices": sum(1 for r in results if r["is_valid"]),
        "invalid_invoices": sum(1 for r in results if not r["is_valid"]),
        "error_counts": dict(error_counts)
    }

    return results, summary


def load_json(input_file):
    with open(input_file, "r", encoding="utf-8") as f:
        return json.load(f)


def save_report(data, output_file):
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    invoices = load_json("extracted_invoices.json")
    results, summary = validate_invoices(invoices)

    print("\n==== VALIDATION SUMMARY ====")
    print(summary)

    save_report({
        "results": results,
        "summary": summary
    }, "validation_report.json")

    print("\nValidation completed! Report saved as validation_report.json")
