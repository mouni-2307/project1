import argparse
from invoice_qc.extractor import extract_invoices_from_folder, save_to_json
from invoice_qc.validator import load_json, validate_invoices, save_report


def run_extract(pdf_dir, output_file):
    invoices = extract_invoices_from_folder(pdf_dir)
    save_to_json(invoices, output_file)
    print(f"\nExtraction completed! Saved to {output_file}")


def run_validate(input_file, report_file):
    invoices = load_json(input_file)
    results, summary = validate_invoices(invoices)
    save_report({"results": results, "summary": summary}, report_file)

    print("\n==== VALIDATION SUMMARY ====")
    print(summary)
    print(f"\nReport saved to {report_file}")


def run_full(pdf_dir, report_file):
    temp_file = "_temp_extraction.json"

    # Extract first
    invoices = extract_invoices_from_folder(pdf_dir)
    save_to_json(invoices, temp_file)
    print("\nExtraction completed!")

    # Now validate
    results, summary = validate_invoices(invoices)
    save_report({"results": results, "summary": summary}, report_file)

    print("\n==== VALIDATION SUMMARY ====")
    print(summary)
    print(f"\nFull run complete! Report saved to {report_file}")


def main():
    parser = argparse.ArgumentParser(description="Invoice QC CLI Tool")

    subparsers = parser.add_subparsers(dest="command")

    # Extract
    extract_cmd = subparsers.add_parser("extract")
    extract_cmd.add_argument("--pdf-dir", required=True)
    extract_cmd.add_argument("--output", required=True)

    # Validate
    validate_cmd = subparsers.add_parser("validate")
    validate_cmd.add_argument("--input", required=True)
    validate_cmd.add_argument("--report", required=True)

    # Full Run
    full_cmd = subparsers.add_parser("full-run")
    full_cmd.add_argument("--pdf-dir", required=True)
    full_cmd.add_argument("--report", required=True)

    args = parser.parse_args()

    if args.command == "extract":
        run_extract(args.pdf_dir, args.output)

    elif args.command == "validate":
        run_validate(args.input, args.report)

    elif args.command == "full-run":
        run_full(args.pdf_dir, args.report)

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
