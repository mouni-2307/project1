from fastapi import FastAPI
from pydantic import BaseModel
from typing import List, Any
from invoice_qc.validator import validate_invoices

app = FastAPI()


@app.get("/health")
def health_check():
    return {"status": "ok"}


class InvoiceModel(BaseModel):
    # We allow any fields since structure is already known
    order_number: Any = None
    order_date: Any = None
    seller_name: Any = None
    buyer_name: Any = None
    currency: Any = None
    net_total: Any = None
    tax_amount: Any = None
    gross_total: Any = None
    line_items: list = []


@app.post("/validate-json")
def validate_json_endpoint(invoices: List[InvoiceModel]):
    # Convert to dicts for validator
    invoice_dicts = [inv.dict() for inv in invoices]

    results, summary = validate_invoices(invoice_dicts)

    return {
        "results": results,
        "summary": summary
    }
