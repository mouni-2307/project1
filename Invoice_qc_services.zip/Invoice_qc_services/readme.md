INVOICE EXTRACTION & QUALITY CONTROL SERVICE – README

OVERVIEW
This project is a backend service designed to extract information from B2B invoice or purchase-order PDF documents, validate that information using custom rules, and expose the workflow using both a Python CLI and a FastAPI HTTP API.

The assignment did not provide any schema or predefined rules, so I designed a realistic invoice data model and a validation logic pipeline based on common business document structures.

WHAT THE SYSTEM DOES
1. Reads PDF invoices and extracts structured fields (identifiers, totals, dates, parties)
2. Validates extracted invoices for completeness, formatting, and business consistency
3. Reports which invoices are valid or invalid, and why
4. Provides both CLI and API-based interfaces

------------------------------------------------------

INVOICE DATA SCHEMA
Each document extracted from PDF follows this structure:

order_number
order_date
seller_name
seller_address (if available)
buyer_name
buyer_address (if available)
currency
net_total
tax_amount
gross_total
line_items (optional list)

Line items are optional; if they are not clearly detectable from PDF tables, an empty list is returned. This keeps the schema consistent and prevents parsing failure.

------------------------------------------------------

VALIDATION RULES
Once invoices are extracted, they are validated using the following checks:

Completeness:
- order_number cannot be empty
- order_date cannot be empty
- seller_name and buyer_name must not be empty

Format Rules:
- order_date must be a valid date format
- currency must be one of EUR, USD, INR
- totals must be numeric

Business Logic:
- net_total + tax_amount should approximately equal gross_total (small tolerance allowed)
- if line_items exist, sum(line_total) should match net_total

Duplicate Detection:
- No two invoices in a single batch should have the same (order_number + order_date + seller_name)

Validation Output:
Each invoice is marked as valid or invalid and includes a list of detected issues.
A summary is also generated for the entire batch.

------------------------------------------------------

SYSTEM WORKFLOW (EXPLAINED NATURALLY)
1. The extractor reads PDFs using pdfplumber and searches for fields using text patterns.
2. Structured invoice objects are written as JSON.
3. The validator loads that JSON and checks rules.
4. CLI or API returns whether each invoice is valid or not and why.

This approach reflects how internal invoice QC systems operate before documents move into accounting or ERP.

------------------------------------------------------

INSTALLATION
1. Create a Python virtual environment
2. Install dependencies using:

pip install -r requirements.txt

Place sample PDFs into a folder named "pdfs" inside the root project directory.

------------------------------------------------------

CLI COMMANDS

Extract PDFs into structured JSON:
python -m invoice_qc.cli extract --pdf-dir pdfs --output extracted.json

Validate existing extracted JSON:
python -m invoice_qc.cli validate --input extracted.json --report validation.json

Full pipeline (extract + validate):
python -m invoice_qc.cli full-run --pdf-dir pdfs --report validation.json

Reports are displayed in terminal and saved to JSON.

------------------------------------------------------

FASTAPI INTERFACE

Start API:
python -m uvicorn invoice_qc.api:app --reload

Health check:
GET http://127.0.0.1:8000/health

Validate JSON invoices via HTTP:
POST http://127.0.0.1:8000/validate-json

Body must be a list of invoices in JSON format.
Example request body:

[
  {
    "order_number": "AUFNR123456",
    "order_date": "02.05.2022",
    "seller_name": null,
    "buyer_name": "Hospital ABC",
    "currency": "EUR",
    "net_total": 216.00,
    "tax_amount": 41.04,
    "gross_total": 257.04,
    "line_items": []
  }
]

You can test with Thunder Client or Postman Desktop.

------------------------------------------------------

ASSUMPTIONS & LIMITATIONS
- Extraction logic is heuristic (no OCR) and may vary depending on formatting
- Line-item parsing is simplified
- Negative totals, refunds, or credit notes not addressed
- Authentication or persistence is not required for assignment
- Schema and rules are intentionally minimal but realistic for QC purposes

------------------------------------------------------

AI USAGE NOTES
AI tools were used for:
- drafting regex ideas
- scaffolding FastAPI routes
- preparing README formatting
- brainstorming validation logic options

Final testing, debugging, data modeling, feature design, and code decisions were done manually.

------------------------------------------------------


